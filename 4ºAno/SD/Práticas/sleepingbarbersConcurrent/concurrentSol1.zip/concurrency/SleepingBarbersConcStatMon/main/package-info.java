/**
 *  Static solution of the Problem of the Sleeping Barbers.
 *  Synchronization is based on implicit monitors.
 */

package main;

