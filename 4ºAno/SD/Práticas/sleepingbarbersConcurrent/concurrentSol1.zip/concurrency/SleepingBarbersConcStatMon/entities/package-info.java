/**
 *  Definition of the entities intervening in the Problem of the Sleeping Barbers.
 *  Static solution based on a posteriori reasoning to terminate the barbers threads.
 */

package entities;

