/**
 *  Definition of the shared regions in the Problem of the Sleeping Barbers.
 *  Static solution with implicit monitors based synchronization.
 */

package sharedRegions;

