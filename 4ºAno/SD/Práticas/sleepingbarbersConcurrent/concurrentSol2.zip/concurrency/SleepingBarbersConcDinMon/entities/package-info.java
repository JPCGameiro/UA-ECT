/**
 *  Definition of the entities intervening in the Problem of the Sleeping Barbers.
 *  Dynaminc solution.
 */

package entities;

