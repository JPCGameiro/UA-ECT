/**
 *  Definition of the shared regions in the Problem of the Sleeping Barbers.
 *  Dynamic solution with implicit monitors based synchronization.
 */

package sharedRegions;

