/**
 *  Definition of the shared regions in the Problem of the Sleeping Barbers.
 *  Dynamic solution with semaphores based synchronization.
 */

package sharedRegions;

