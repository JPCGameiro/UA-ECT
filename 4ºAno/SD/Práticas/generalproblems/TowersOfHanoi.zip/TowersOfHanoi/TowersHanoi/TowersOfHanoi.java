package TowersHanoi;

/**
 *    Interface to both recursive and iterative solutions.
 */

public interface TowersOfHanoi
{
  /**
   *  Solving the problem.
   */

   public void problemSolving ();
}
