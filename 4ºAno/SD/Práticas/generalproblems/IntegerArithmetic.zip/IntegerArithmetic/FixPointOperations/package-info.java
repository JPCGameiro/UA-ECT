/**
 *  Library for the basic arithmetic operations having as operands decimal integers with a variable number of digits.
 *  Processing is symbolic according to the algorithms learned at primary school.
 *
 *    The following operations are implemented
 *     - addition
 *     - multiplication.
 */

package FixPointOperations;

