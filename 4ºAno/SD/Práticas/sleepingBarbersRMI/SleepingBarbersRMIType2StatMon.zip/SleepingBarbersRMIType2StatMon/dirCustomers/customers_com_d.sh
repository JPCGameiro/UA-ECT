java clientSide.main.ClientSleepingBarbersCustomer l040101-ws08.ua.pt 22000 stat 3
