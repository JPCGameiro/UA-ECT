/**
 *  Interfaces to remote objects for the Problem of the Sleeping Barbers.
 *
 *    Communication is based on Java RMI.
 */

package interfaces;
